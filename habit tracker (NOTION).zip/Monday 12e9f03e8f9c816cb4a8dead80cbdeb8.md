# Monday

Date: June 26, 2023
Wake Up Early: Yes
Meditate: Yes
Exercise: Yes
Journal: Yes
Read: Yes
Drink Water: Yes
Progress: 1
Month: June 2023 (June%202023%2012e9f03e8f9c810399b1d1e474193ee6.md)