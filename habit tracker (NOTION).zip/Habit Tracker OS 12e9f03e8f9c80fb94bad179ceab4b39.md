# Habit Tracker OS

<aside>
<img src="https://www.notion.so/icons/inbox_gray.svg" alt="https://www.notion.so/icons/inbox_gray.svg" width="40px" /> Add a description

</aside>

[https://indify.co/widgets/live/clock/YpDLwr8JPWpM146KIFjN](https://indify.co/widgets/live/clock/YpDLwr8JPWpM146KIFjN)

<aside>
<img src="https://www.notion.so/icons/circle_gray.svg" alt="https://www.notion.so/icons/circle_gray.svg" width="40px" /> **Quick Buttons**

</aside>

<aside>
<img src="https://www.notion.so/icons/circle_gray.svg" alt="https://www.notion.so/icons/circle_gray.svg" width="40px" /> **Create New Day**

</aside>

---

[Untitled](Untitled%2012e9f03e8f9c81d1b9e9f36723c77716.csv)

![swapna.png](swapna.png)

<aside>
<img src="https://www.notion.so/icons/compose_gray.svg" alt="https://www.notion.so/icons/compose_gray.svg" width="40px" /> **Quick Notes**

---

</aside>

<aside>
<img src="https://www.notion.so/icons/checkmark_gray.svg" alt="https://www.notion.so/icons/checkmark_gray.svg" width="40px" /> **Habits Overview**

[Untitled](Untitled%2012e9f03e8f9c814895c6d94325fa60f0.csv)

</aside>

<aside>
<img src="https://www.notion.so/icons/calendar_gray.svg" alt="https://www.notion.so/icons/calendar_gray.svg" width="40px" /> **Weekly View**

[Untitled](Untitled%2012e9f03e8f9c818eb1fef7fc3b85f723.csv)

</aside>

<aside>
<img src="https://www.notion.so/icons/calendar_gray.svg" alt="https://www.notion.so/icons/calendar_gray.svg" width="40px" /> **Calendar**

[Untitled](Untitled%2012e9f03e8f9c8130b386ecfd9f9972b0.csv)

</aside>

---

### Database

[Habit Tracker](Habit%20Tracker%2012e9f03e8f9c815bb81efe62925057ed.csv)

[Monthly Habits Report](Monthly%20Habits%20Report%2012e9f03e8f9c814c87fac8ab253ff7cf.csv)

---

![Notion Avatar.png](Notion_Avatar.png)

## Hi, I’m Sourabh

I am the creator behind this template, if you liked my work and want to support it, please consider buying me a coffee ☕ [here](https://www.buymeacoffee.com/iamsourabhshen) 

<aside>
<img src="https://super.so/icon/dark/twitter.svg" alt="https://super.so/icon/dark/twitter.svg" width="40px" /> [Twitter](https://twitter.com/iamsourabhshen)

</aside>

<aside>
<img src="https://super.so/icon/dark/shopping-bag.svg" alt="https://super.so/icon/dark/shopping-bag.svg" width="40px" /> [Gumroad](https://iamsourabhshen.gumroad.com/)

</aside>

<aside>
<img src="https://super.so/icon/dark/link.svg" alt="https://super.so/icon/dark/link.svg" width="40px" /> [Become an affiliate](https://iamsourabhshen.gumroad.com/affiliates)

</aside>

<aside>
<img src="https://super.so/icon/dark/instagram.svg" alt="https://super.so/icon/dark/instagram.svg" width="40px" /> [Instagram](https://www.instagram.com/iamsourabh_shen/)

</aside>

<aside>
<img src="https://super.so/icon/dark/mail.svg" alt="https://super.so/icon/dark/mail.svg" width="40px" /> [Email us](mailto:iamsourabh91@gmail.com)

</aside>