# Passport photo

Date: October 5, 2023