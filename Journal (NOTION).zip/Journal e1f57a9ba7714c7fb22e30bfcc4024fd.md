# Journal

> ***Quote of your choice which gives you happy and motivational vibes.***
> 

---

## **My Monthly Journal**

![download.jpg](download.jpg)

![images.jpg](images.jpg)

![images.jpg](images%201.jpg)

---

[Habit Tracker](Habit%20Tracker%206b3cce6b33f240e38e24ac9d6d245265.csv)

---

---

- Misc
    
    [1st Quarter](1st%20Quarter%202d469bc0ec4e4f3f91a53bf00377aebb.md)
    
    [2nd Quarter ](2nd%20Quarter%2064a2f56ef0884e11b2232d3d0aeddcad.md)
    
    [3rd Quarter](3rd%20Quarter%20a44ccae9a1254180abec617b53a15e89.md)
    
    [4th Quarter](4th%20Quarter%205795f72906564c88aa96475174e69038.md)
    

[Task Log](Task%20Log%206723f16918c44b6380ed76412a9467f7.md)