# #Volunteering

Date: October 7, 2023

[Gandhi Smarak Vidyalaya](https://www.google.com/maps?sca_esv=570868123&output=search&q=gandhi+smarak+vidyalaya&source=lnms&entry=mc&sa=X&ved=2ahUKEwihweSo7N2BAxVK7TgGHV39DekQ0pQJegQIDRAB) 

[Supertech Capetown to Gandhi Smarak Vidyalaya - Google Maps](https://www.google.com/maps/dir/Supertech+Capetown,+Sector+74,+Noida,+Uttar+Pradesh,+India/H8WV%2BFQ8+Gandhi+Smarak+Vidyalaya,+Hospital+Marg,+Chora+Sadatpur,+Sector+22,+Noida,+Uttar+Pradesh+201301/@28.6058277,77.3500057,13.59z/data=!4m15!4m14!1m5!1m1!1s0x390cef689f05381b:0x9a78e317fb135e8d!2m2!1d77.3905778!2d28.5745096!1m5!1m1!1s0x390ce50f5a94b4c7:0x71c9bcbab6b14f66!2m2!1d77.3444667!2d28.5961686!3e9!5i2?entry=ttu)

[iVolunteer | Brush Up Your Volunteering Spirit this Daan Utsav!](https://www.ivolunteer.in/opportunity/a0COX00000DEBYt2AP/brush-up-your-volunteering-spirit-this-daan-utsav)