# Lines

- hr shakhs saneha ha, r zaat ek kahani ha
- 
- 
- 
-