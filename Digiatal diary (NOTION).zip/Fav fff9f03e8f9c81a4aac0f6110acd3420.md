# Fav

$\color{#E8BFC4}\rule{691px}{2px}$

[Lines](Lines%20fff9f03e8f9c8163a9cdf9d3cb88c7bd.md)

[Games](Games%207426386f93b341be99224ac629e25b69.md)

[Shops and stores](Shops%20and%20stores%20fff9f03e8f9c81d88ebbd8c5d7ed8454.md)

[Fun facts about me](Fun%20facts%20about%20me%20fff9f03e8f9c8112970df0438cf0dcc9.md)