# A pretty girl’s diary

$\color{#E8BFC4}\rule{691px}{2px}$

[A pretty girl’s diary](A%20pretty%20girl%E2%80%99s%20diary%20fff9f03e8f9c81ebb045fe075b1b89f6.csv)