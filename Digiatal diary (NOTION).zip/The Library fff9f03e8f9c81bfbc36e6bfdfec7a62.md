# The Library

$\color{#E8BFC4}\rule{691px}{2px}$

<aside>
<img src="https://www.notion.so/icons/exclamation-mark_lightgray.svg" alt="https://www.notion.so/icons/exclamation-mark_lightgray.svg" width="40px" /> ***B O O K S   T O   R E A D***

$\color{#E8BFC4}\rule{175px}{2px}$

- Jurh
- 
- 
- 
</aside>

<aside>
<img src="https://www.notion.so/icons/bookmark_lightgray.svg" alt="https://www.notion.so/icons/bookmark_lightgray.svg" width="40px" /> ***B O O K S   O N   H O L D***

$\color{#E8BFC4}\rule{175px}{2px}$

- Bakht
- Usri Yusra
- Mann o Salwa
- 
</aside>

<aside>
<img src="https://www.notion.so/icons/stars_lightgray.svg" alt="https://www.notion.so/icons/stars_lightgray.svg" width="40px" /> ***W I S H L I S T***

$\color{#E8BFC4}\rule{175px}{2px}$

- [ ]  1st book
- [ ]  2nd book
- [ ]  3rd book
- [ ]  4th book
</aside>

$\color{#E8BFC4}\rule{691px}{2px}$

[Reading list](Reading%20list%20fff9f03e8f9c810eac9fccee6cbc5761.csv)