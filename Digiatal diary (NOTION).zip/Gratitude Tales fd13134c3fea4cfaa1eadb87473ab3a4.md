# Gratitude Tales

<aside>
<img src="https://www.notion.so/icons/heart_lightgray.svg" alt="https://www.notion.so/icons/heart_lightgray.svg" width="40px" /> DELETE THIS LATER: Click the “New month” button to add a new month then rename it! If you want to add in habits or delete habits, click the “Edit button” next to the “New month” button, then edit the “Month” block in there for permanant changes. Now every time you add a new month, your habits will fit your needs! 

Sorry if it’s a bit complex, I tried to make it as simple as possible!

</aside>

$\color{#E8BFC4}\rule{691px}{2px}$

[Month](Month%2052fd0da5556a4293893dc2fbfdbdaeb5.md)

$\color{#E8BFC4}\rule{691px}{2px}$

### — Archive