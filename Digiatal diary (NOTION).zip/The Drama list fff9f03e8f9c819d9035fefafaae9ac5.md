# The Drama list

$\color{#E8BFC4}\rule{691px}{2px}$

![Untitled](Untitled%202.png)

[Series](Series%20fff9f03e8f9c8190ae53deb000028a59.md)

![Untitled](Untitled%203.png)

[Films](Films%20fff9f03e8f9c81aba2b1c582328cd78c.md)

## — Bulletin board

- Watch “Dil, Dosti, Dilemma”
- Should watch “Atypical Family” and “Call me BAE” soon~
- Love adhura
- Downloads playlist
- 
- 

![Untitled](Untitled%204.png)

$\color{#E8BFC4}\rule{691px}{2px}$