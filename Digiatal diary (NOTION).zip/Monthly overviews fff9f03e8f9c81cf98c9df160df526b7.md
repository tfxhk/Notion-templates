# Monthly overviews

<aside>
<img src="https://www.notion.so/icons/heart_lightgray.svg" alt="https://www.notion.so/icons/heart_lightgray.svg" width="40px" /> DELETE THIS LATER: Click the “New month” button to add a new month then rename it!

</aside>

$\color{#E8BFC4}\rule{691px}{2px}$

[September](September%20fff9f03e8f9c81c3a04ff812faec5727.md)

$\color{#E8BFC4}\rule{691px}{2px}$

### — Archive