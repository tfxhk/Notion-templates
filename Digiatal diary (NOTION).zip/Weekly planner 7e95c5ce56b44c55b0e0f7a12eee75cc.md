# Weekly planner

$\color{#E8BFC4}\rule{691px}{2px}$

## — Monday

- [ ]  Diary writing
- [ ]  Uniform press + Uni preps
- [ ]  Water bottle
- [ ]  200 Rs.
- [ ]  Sleep at 1
- [ ]  Oiling

## — Tuesday

- [ ]  wake-up at 6
- [ ]  Morning walk
- [ ]  breakfast at 7
- [ ]  Take bath
- [ ]  Bag pack
- [ ]  Navigator download

## — Wednesday

- [ ]  
- [ ]  
- [ ]  

## — Thursday

- [ ]  
- [ ]  
- [ ]  

## — Friday

- [ ]  
- [ ]  
- [ ]  

## — Saturday

- [ ]  
- [ ]  
- [ ]  

## — Sunday

- [ ]  
- [ ]  
- [ ]  

## — Groceries

- Strawberry milk
- Lettuce
- Onions
- Carrots

$\color{#E8BFC4}\rule{691px}{2px}$

## — Weekly Goals

---

> Write an email to Mrs. Flora
> 

> Go grocery shopping
> 

> Stop by at Amanda’s house
> 

## — Reminders

---

- Name of Reminder August 5, 2023
- Name of Reminder August 5, 2023

[weekly schedule](weekly%20schedule%20ac17868e3cb744e1a573d714c09586ae.csv)