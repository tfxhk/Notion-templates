# September

> — Welcome September, time to turn over a new leaf 🍂
> 

$\color{#E8BFC4}\rule{341px}{2px}$

### — Intentions

1. 
2. 
3. 

### — Goals

…

### — What I have accomplished this month:

- 
- 
- 

### — What I learned this month:

…