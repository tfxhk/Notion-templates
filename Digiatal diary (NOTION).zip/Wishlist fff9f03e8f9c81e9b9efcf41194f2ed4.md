# Wishlist

$\color{#E8BFC4}\rule{691px}{2px}$

### — Clothes

- 
- 

### — Beauty

- 
- 

### — Room decor

- 
- 

### — Misc.

- 
-