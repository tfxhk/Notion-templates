# weekly to-do template

*“no history, no self. know history, know self.”*   

---

![Screen Shot 2022-11-30 at 1.07.47 PM.png](Screen_Shot_2022-11-30_at_1.07.47_PM.png)

## monday ☆

---

- *uni*
- [ ]  
- *work*
- [ ]  
- *home*
- [ ]  
- *laptop*
- [ ]  
- life
- [ ]  club points Reem
- [ ]  club points vixen
- [ ]  vixen club points
- [ ]  vixen game lvl
- [ ]  daily reward vixen
- [ ]  daily reward Reem

![Screen Shot 2022-11-30 at 1.04.10 PM.png](Screen_Shot_2022-11-30_at_1.04.10_PM.png)

## tuesday ☆

---

- *uni*
- [ ]  
- *work*
- [ ]  
- *home*
- [ ]  Take bath
- [ ]  oiling
- *laptop*
- [ ]  
- life
- [ ]  club points Reem
- [ ]  club points vixen
- [ ]  vixen club points
- [ ]  vixen game lvl
- [ ]  daily reward vixen
- [ ]  daily reward Reem

![Screen Shot 2022-11-30 at 1.03.50 PM.png](Screen_Shot_2022-11-30_at_1.03.50_PM.png)

## wednesday ☆

---

- *uni*
- [ ]  
- *work*
- [ ]  
- *home*
- [ ]  
- *laptop*
- [ ]  
- life
- [ ]  club points Reem
- [ ]  club points vixen
- [ ]  vixen club points
- [ ]  vixen game lvl
- [ ]  daily reward vixen
- [ ]  daily reward Reem

![Screen Shot 2022-11-30 at 1.06.10 PM.png](Screen_Shot_2022-11-30_at_1.06.10_PM.png)

## thursday ☆

---

- *uni*
- [ ]  
- *work*
- [ ]  
- *home*
- [ ]  
- *laptop*
- [ ]  
- life
- [ ]  club points Reem
- [ ]  club points vixen
- [ ]  vixen club points
- [ ]  vixen game lvl
- [ ]  daily reward vixen
- [ ]  daily reward Reem

![Screen Shot 2022-11-30 at 1.05.03 PM.png](Screen_Shot_2022-11-30_at_1.05.03_PM.png)

## friday ☆

---

- *uni*
- [ ]  
- *work*
- [ ]  
- *home*
- [ ]  
- *laptop*
- [ ]  
- life
- [ ]  club points Reem
- [ ]  club points vixen
- [ ]  vixen club points
- [ ]  vixen game lvl
- [ ]  daily reward vixen
- [ ]  daily reward Reem

![Screen Shot 2022-11-30 at 1.06.39 PM.png](Screen_Shot_2022-11-30_at_1.06.39_PM.png)

## sat/sun ☆

---

- *uni*
- [ ]  
- *work*
- [ ]  
- *home*
- [ ]  
- *laptop*
- [ ]  
- life
- [ ]  club points Reem
- [ ]  club points vixen
- [ ]  vixen club points
- [ ]  vixen game lvl
- [ ]  daily reward vixen
- [ ]  daily reward Reem